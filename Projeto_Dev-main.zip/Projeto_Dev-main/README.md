# Projeto_Dev
Projeto de software do programa Desafio GoDev 2021 entre a Senior e a ProWay.


1. Descrição 

 Visão geral: O sistema presente nesse repositório serve para gerenciar um treinamento realizado em diversas salas com lotação variável com diversas pessoas.
 
2. O projeto 

2.1. Visão geral: Nenhuma biblioteca foi importada para o projeto além das bibliotecas padrões do Java. O projeto consiste em 11 classes divididas em 4 pacotes e foi desenvolvido pelo IDE Eclipse.
2.2 Estrutura: o projeto está dividido em 4 pacotes: um pacote para a interface, outro para a parte lógica, outro para gravar os dados, e por fim, outro para os catálogos gravados. A estrutura foi escolhida para que todas as classes fiquem bem divididas e organizadas, deixando assim, o projeto mais apresentável.
 
3. Como funciona: 

O software apresenta a interface pelo console, assim, começa com um menu inicial sendo as opções para cadastrar pessoas e remover pessoas cadastradas (só é possível cadastrar se existe alguma sala cadastrada), e para o cadastro de pessoas, basta informar o nome e o sobrenome, e em qual sala será alocada (tanto a sala do evento quanto a do café, visto que todos precisam realizar a pausa café). Também tem a opção de cadastrar sala para alocar as pessoas, podendo ser a sala de eventos ou a de café, e além do nome, você cadastra a lotação da sala cadastrada. Também é possível remover as salas cadastradas. Por fim, é possível consultar todas as pessoas cadastradas e as suas respectivas salas.
 
